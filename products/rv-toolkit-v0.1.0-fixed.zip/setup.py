"""setup.py fallback for legacy pip installations."""
from setuptools import setup, find_packages

setup(
    name="rv-toolkit",
    version="0.1.0",
    description="Representational Volume metrics for transformer interpretability",
    author="AIKAGRYA Research",
    packages=find_packages(),
    install_requires=[
        "torch>=1.9.0",
        "numpy>=1.19.0",
        "transformers>=4.20.0",
    ],
    python_requires=">=3.8",
)